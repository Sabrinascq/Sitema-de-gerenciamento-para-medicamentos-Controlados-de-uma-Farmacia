
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author PC GAMER
 */
public class ClienteDAO {
    private Connection connection;
    int telefone;
    String endereco;

    public void adiciona(Cliente cliente){
        String sql = "INSERT INTO Cliente(telefone,endereco) VALUES(43988632104,Rua Amador Lopes Vilar)";
    
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
           // stmt.setString(1, cliente.getTelefone());
            stmt.setString(2, cliente.getEndereco());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
}

